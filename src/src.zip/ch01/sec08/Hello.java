package ch01.sec08;

// 클래스 Full Name: ch01.sec08.Hello

/*
       클래스 선언
       Hello: 클래스명
       public 클래스명은 파일명과 동일하다.



 */
public class Hello {
    /* main 메소드 선언
       main: 메소드명
       main 메소드는 프로그램의 시작점.




     */
    public static void main(String[] args) {
        // " " 쌍따옴표 사이는 문자열. 문자열 안에서는 주석처리 안 된다.
        System.out.println("Hello, /*이거 주석 아님*/ Java"); // println 메소드 호출

    }

}

class Hi{

}
