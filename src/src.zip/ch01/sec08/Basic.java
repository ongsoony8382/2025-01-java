package ch01.sec08;

public class Basic {
    public static void main(String[] args) {
        int x; //정수값을 담을 수 있는 변수 x를 선언했다.
        x = 1; // x에 1을 넣는다. (초기화), 1은 리터럴, =은 대입 연산자(쓰기 작업, 변수 값이 변한다.)
        int y = 2; // 변수 y를 선언하였고 2로 초기화했다.

        int sum = x + y ; // 변수 sum을 선언하였고, x와 y를 더한 값으로 초기화 하였다.

        // int sum = 1 + 2 ;
        // int sum = 3;
        System.out.println(sum);
        System.out.println(3);
    }
}
