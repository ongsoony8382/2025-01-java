package ch02.sec03;

public class charExample {
    public static void main(String[] args) {
        char ch1 = 'A';

        System.out.printf("ch1: %c, %d\n", ch1, (int)ch1);
        System.out.printf("66: %c, %d\n", 66, 66);
        System.out.printf("66: %c, %d\n", 67, 67);
    }
}
