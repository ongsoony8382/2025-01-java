package ch02.sec01;

public class VariableInitExample {
    public static void main(String[] args) {
        int value; // (지역변수) 변수 선언, 초기화 한 적 없음


        //int result = value + 10; // 사용하려고 하면 컴파일 에러가 난다.

       // System.out.println(result);
    }
}
